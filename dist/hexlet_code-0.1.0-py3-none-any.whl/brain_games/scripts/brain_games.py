#!/usr/bin/env python
from ..cli import welcome_user
def main():
    print("Weilcome to the Brain Games!")
    name = welcome_user()
    print("Hello, "+name+"!")
