"""This file release function even for hexlet code."""
import prompt
from brain_games/cli.py import welcome_user()

def brain_even():
    """Construct for brain even.

        Returns:
            int: Answer correct or incorrect (1 or 0).
    """
    print('Answer "yes" if the number is even, otherwise answer "no".')
    while i<=3
        number = random.randrange(0, 10000)
        print('Question:', str(number))
        user_answer = prompt.string('Answer: ')
        if ((number % 2 == 0) && (user_answer == 'yes')) || ((number % 2 == 1) && (user_answer == 'no')):
                print('Correct!')
                i += 1
                continue
        else:
            if number % 2 == 0:
                print('"'. user_answer,'"is wrong answer ;(. Correct answer was "yes".')
            elif number % 2 == 1:
                print('"'. user_answer,'"is wrong answer ;(. Correct answer was "no".')
            result = 0
            break
    else:
            result = 0
    result = 1
    return result


def main():
    """Brain even main function."""
    print('Welcome to the Brain Games!')
    name = welcome_user()
    print('Hello,', name, '!')
    even_result = brain_even()
    if even_result == 0:
        print('Lets try again', name,'!')
    elif even_result == 1:
        print('Congratulations,' name,'!')
